import os, sys, random, string, re

with open(".\\compiled\\release.luau", "r", encoding="utf-8") as f:
	script_data = f.read()

REPLACEMENTS = {
	# Random 5 hexadecimal characters
	"||RHEX5||": lambda: ''.join(random.choice(string.hexdigits).lower() for _ in range(5)),
	"--[[SCRIPTINS]]": lambda: script_data,
}

# Open the file in the first argument and replace the placeholders with the replacements
def process_file(file_path : str):
	with open(file_path, "r", encoding="utf-8") as file:
		content = file.read()

	for placeholder, replacement in REPLACEMENTS.items():
		if placeholder == "||RHEX5||":
			content = re.sub(re.escape(placeholder), lambda m: replacement(), content)
		else:
			content = content.replace(placeholder, replacement())

	# Generate output file path by replacing the .luau suffix with _pre1.luau
	with open('compiled/loader.luau', 'w', encoding='utf-8') as file:
		file.write(content)

if __name__ == "__main__":
	# Check if the script is being run directly
	if len(sys.argv) < 2:
		print("Please provide a file path as an argument.")
		sys.exit(1)

	# Get the file path from the command line arguments
	file_path = sys.argv[1]

	# Check if the file exists
	if not os.path.isfile(file_path):
		print(f"The file {file_path} does not exist.")
		sys.exit(1)

	# Process the file
	process_file(file_path)
	print(f"Processed {file_path} and saved as {file_path[:-5]}_pre1.luau")


