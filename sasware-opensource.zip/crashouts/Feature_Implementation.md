Analyze the following code, look at how PrinterFarm is implemented in main.luau (The cycle for purchasing and depositing bought items into the Pot is about the same as PrinterFarm, just different paths.)

Implement BakerFarm with the same functionality / features of printerfarm.

The goal is to automate the entire job without actually interacting with anything, just firing remotes.

Module path: game.ReplicatedStorage.Modules.Client.Modules.CookerJob

```
local v0 = {};
local l_ReplicatedStorage_0 = game:GetService("ReplicatedStorage"); 
local l_TweenService_0 = game:GetService("TweenService");
local l_UserInputService_0 = game:GetService("UserInputService");
local _ = game:GetService("SoundService");
local l_RunService_0 = game:GetService("RunService");
local v6 = require(l_ReplicatedStorage_0.Modules.Client.Controllers["InventoryClientV4.5"]);
local v7 = require(l_ReplicatedStorage_0.Modules.Client.Controllers.Movement);
local v8 = require(l_ReplicatedStorage_0.Modules.Packages.Net);
local v9 = require(l_ReplicatedStorage_0.Modules.ClientFramework);
local v10 = require(l_ReplicatedStorage_0.Modules.Utils.IsFPS);
local v11 = require(l_ReplicatedStorage_0.Modules.Client.Modules.Notify);
local v12 = v8:RemoteFunction("BakerEvent");
local l_CurrentCamera_0 = workspace.CurrentCamera;
local v14 = false;
local l_LocalPlayer_0 = game.Players.LocalPlayer;
local l_CookerJob_0 = l_LocalPlayer_0.PlayerGui.UI.Hud.CookerJob;
lerp = function(v17, v18, v19) --[[ Line: 26 ]] --[[ Name: lerp ]]
    return v17 + (v18 - v17) * v19;
end;
v0.Start = function(v20) --[[ Line: 30 ]] --[[ Name: Start ]]
    -- upvalues: v14 (ref), l_LocalPlayer_0 (copy), v11 (copy), v12 (copy), v9 (copy), v10 (copy), l_CurrentCamera_0 (copy), v7 (copy), v6 (copy), l_CookerJob_0 (copy), l_TweenService_0 (copy), l_UserInputService_0 (copy), l_RunService_0 (copy)
    if v14 then
        return;
    else
        local v21 = false;
        local v22 = false;
        for _, v24 in l_LocalPlayer_0.Inventory:GetChildren() do
            if v24.Value == "Cookie Packet" then
                v21 = true;
            elseif string.sub(v24.Value, -5) == "Flour" then
                v22 = true;
            end;
        end;
        if not v21 and not v22 then
            v11.bottom("You do not have the ingredients.");
            return;
        elseif not v21 then
            v11.bottom("You do not have the packaging.");
            return;
        elseif not v22 then
            v11.bottom("You do not have flour.");
            return;
        else
            v14 = true;
            if not v12:InvokeServer("Start") then
                v14 = false;
                return;
            else
                v9.Local.HRP.Anchored = true;
                if v10() then
                    l_LocalPlayer_0.CameraMinZoomDistance = 3;
                    task.wait(0.1);
                end;
                local l_CFrame_0 = l_CurrentCamera_0.CFrame;
                l_CurrentCamera_0.CameraType = Enum.CameraType.Scriptable;
                l_LocalPlayer_0.Character.PrimaryPart = l_LocalPlayer_0.Character.HumanoidRootPart;
                l_LocalPlayer_0.Character:SetPrimaryPartCFrame(v20.Parent.Pos.CFrame);
                v7.DisableMovement = true;
                v6.HideInventory("CookerJob", 2);
                l_CookerJob_0.Visible = true;
                local v26 = {};
                local v27 = nil;
                local v28 = nil;
                local v29 = nil;
                local v30 = nil;
                local v31 = false;
                local function v34() --[[ Line: 86 ]] --[[ Name: Update ]]
                    -- upvalues: l_CookerJob_0 (ref), l_TweenService_0 (ref), v29 (ref), v9 (ref), l_UserInputService_0 (ref), v28 (ref)
                    l_CookerJob_0.Icon.Visible = true;
                    l_TweenService_0:Create(l_CookerJob_0.Bar.Frame.Fill, TweenInfo.new(0.25, Enum.EasingStyle.Sine), {
                        Size = UDim2.new(v29.Progress / v29.MaxProgress, 0, 1, 0)
                    }):Play();
                    if v29.Mode == "Click" then
                        l_CookerJob_0.Label.Text = "Click Rapidly";
                        local v32 = v9.Local.Device == "PC" and "rbxassetid://7031930012" or v9.Local.Device == "Console" and l_UserInputService_0:GetImageForKeyCode(Enum.KeyCode.ButtonR2) or "http://www.roblox.com/asset/?id=13060727541";
                        l_CookerJob_0.Icon.Image = v32;
                        if v28 then
                            v28:Stop(0);
                        end;
                        v28 = v9.Local.Animator:LoadAnimation(script.CutM1);
                        v28:Play(0);
                        local v33 = script.Chop:Clone();
                        v33.Parent = v9.Local.Character.RightHand;
                        v33:Play();
                        game.Debris:AddItem(v33, 2);
                        return;
                    elseif v29.Mode == "LeftRight" then
                        if v9.Local.Device == "PC" then
                            l_CookerJob_0.Label.Text = "Move mouse left and right";
                            l_CookerJob_0.Icon.Image = "http://www.roblox.com/asset/?id=13352905212";
                            return;
                        elseif v9.Local.Device == "Console" then
                            l_CookerJob_0.Label.Text = "Hold";
                            l_CookerJob_0.Icon.Image = l_UserInputService_0:GetImageForKeyCode(Enum.KeyCode.ButtonX);
                            return;
                        else
                            l_CookerJob_0.Icon.Image = "http://www.roblox.com/asset/?id=13060727541";
                            l_CookerJob_0.Label.Text = "Swipe left and right";
                            return;
                        end;
                    else
                        if v29.Mode == "Cook" then
                            l_CookerJob_0.Icon.Visible = false;
                            l_CookerJob_0.Label.Text = "Cooking..";
                        end;
                        return;
                    end;
                end;
                local function v37(v35) --[[ Line: 121 ]] --[[ Name: cleanUp ]]
                    -- upvalues: v9 (ref), v27 (ref), v28 (ref), v29 (ref), v20 (copy)
                    if v9.Local.Character:FindFirstChild("AntCookProp") then
                        v9.Local.Character.AntCookProp:Destroy();
                    end;
                    if v9.Local.Character:FindFirstChild("AntCookProp2") then
                        v9.Local.Character.AntCookProp2:Destroy();
                    end;
                    if v27 then
                        v27:Stop();
                        v27 = nil;
                    end;
                    if v28 then
                        v28:Stop();
                        v28 = nil;
                    end;
                    if (v35 or v29 and v29.Mode == "Cook") and v20.Parent.CuttingBoard:FindFirstChild("Dough") then
                        v20.Parent.CuttingBoard.Dough:Destroy();
                    end;
                    if v20.Parent.Pan:FindFirstChild("Cookie") then
                        v20.Parent.Pan.Cookie:Destroy();
                    end;
                    local l_FX_0 = v20.Parent.Pan.FX;
                    l_FX_0.Fire.Enabled = false;
                    l_FX_0.ParticleEmitter.Enabled = false;
                    l_FX_0.PointLight.Enabled = false;
                    l_FX_0.Sound:Stop();
                end;
                local function v50() --[[ Line: 150 ]] --[[ Name: nextMode ]]
                    -- upvalues: v29 (ref), v12 (ref), v31 (ref), l_LocalPlayer_0 (ref), v20 (copy), v30 (ref), l_UserInputService_0 (ref), v37 (copy), v9 (ref), v27 (ref), l_TweenService_0 (ref), l_CurrentCamera_0 (ref), v34 (copy)
                    if v29 and v29.SubMode == "Package" then
                        v12:InvokeServer("Finish");
                        v31 = true;
                        return;
                    else
                        v29 = {
                            Mode = v29 == nil and "Click" or v29.Mode == "Click" and "LeftRight" or v29.Mode == "LeftRight" and "Cook" or "LeftRight", 
                            SubMode = v29 and v29.Mode == "Click" and "Salt" or v29 and v29.Mode == "Cook" and "Package" or nil, 
                            Progress = 0, 
                            MaxProgress = v29 == nil and 20 or 30
                        };
                        if v29.Mode == "Cook" then
                            l_LocalPlayer_0.Character:SetPrimaryPartCFrame(v20.Parent.Pos2.CFrame);
                        elseif v29.SubMode == "Package" then
                            l_LocalPlayer_0.Character:SetPrimaryPartCFrame(v20.Parent.Pos3.CFrame);
                        end;
                        v30 = l_UserInputService_0:GetMouseLocation().X;
                        v37();
                        if v29.Mode == "Click" then
                            local v38 = script.AntKnife:Clone();
                            v38.Parent = v9.Local.Character;
                            v38.Name = "AntCookProp";
                            local l_Motor6D_0 = Instance.new("Motor6D");
                            l_Motor6D_0.Parent = v38;
                            l_Motor6D_0.Part0 = v9.Local.Character.RightHand;
                            l_Motor6D_0.Part1 = v38;
                            l_Motor6D_0.C0 = CFrame.new(0, -0.200000003, -0.899999976, -4.37113883E-8, 1, 4.37113883E-8, -0, -4.37113883E-8, 1, 1, 4.37113883E-8, 1.91068547E-15);
                            v27 = v9.Local.Animator:LoadAnimation(script.CutIdle);
                            v27:Play();
                            local v40 = script.Dough:Clone();
                            v40.Parent = v20.Parent.CuttingBoard;
                            v40:SetPrimaryPartCFrame(v20.Parent.CuttingBoard.Primary.CFrame);
                        elseif v29.SubMode == "Package" then
                            v27 = v9.Local.Animator:LoadAnimation(script.PackageIdle);
                            v27:Play();
                            local v41 = script.CookedCookie:Clone();
                            v41.Parent = v9.Local.Character;
                            v41.Name = "AntCookProp";
                            local l_Motor6D_1 = Instance.new("Motor6D");
                            l_Motor6D_1.Parent = v41;
                            l_Motor6D_1.Part0 = v9.Local.Character.RightHand;
                            l_Motor6D_1.Part1 = v41;
                            local v43 = script.CookiePacket:Clone();
                            v43.Parent = v9.Local.Character;
                            v43.Name = "AntCookProp2";
                            local l_Motor6D_2 = Instance.new("Motor6D");
                            l_Motor6D_2.Parent = v43;
                            l_Motor6D_2.Part0 = v9.Local.Character.LeftHand;
                            l_Motor6D_2.Part1 = v43;
                        elseif v29.SubMode == "Salt" then
                            v27 = v9.Local.Animator:LoadAnimation(script.SaltIdle);
                            v27:Play();
                        elseif v29.Mode == "Cook" then
                            v27 = v9.Local.Animator:LoadAnimation(script.PanIdle);
                            v27:Play();
                            local l_FX_1 = v20.Parent.Pan.FX;
                            l_FX_1.Fire.Enabled = true;
                            l_FX_1.ParticleEmitter.Enabled = true;
                            l_FX_1.PointLight.Enabled = true;
                            l_FX_1.Sound:Play();
                            local v46 = script.Cookie:Clone();
                            v46.Parent = v20.Parent.Pan;
                            v46:SetPrimaryPartCFrame(v20.Parent.Pan.Primary.CFrame);
                        end;
                        if v29.SubMode == "Salt" then
                            local v47 = script.Salt:Clone();
                            v47.Parent = v9.Local.Character;
                            v47.Name = "AntCookProp";
                            local l_Motor6D_3 = Instance.new("Motor6D");
                            l_Motor6D_3.Parent = v47.Handle;
                            l_Motor6D_3.Part0 = v9.Local.Character.RightHand;
                            l_Motor6D_3.Part1 = v47.Handle;
                            l_Motor6D_3.C0 = CFrame.new(-0.100000001, -0.200000003, -0.200000003, -1, -1.50995803E-7, 6.60023616E-15, -0, -4.37113883E-8, -1, 1.50995803E-7, -1, 4.37113883E-8);
                        end;
                        local l_CFrame_1 = v20.Parent[(if v29.SubMode ~= nil then v29.SubMode else v29.Mode) .. "Cam"].CFrame;
                        l_TweenService_0:Create(l_CurrentCamera_0, TweenInfo.new(0.5, Enum.EasingStyle.Back), {
                            CFrame = l_CFrame_1
                        }):Play();
                        v34();
                        return;
                    end;
                end;
                v50();
                table.insert(v26, l_UserInputService_0.InputBegan:Connect(function(v51, v52) --[[ Line: 234 ]]
                    -- upvalues: v29 (ref), v34 (copy), v50 (copy)
                    if v52 then
                        return;
                    else
                        if v29.Mode == "Click" and (v51.UserInputType == Enum.UserInputType.MouseButton1 or v51.KeyCode == Enum.KeyCode.ButtonR2 or v51.UserInputType == Enum.UserInputType.Touch) then
                            local l_v29_0 = v29;
                            l_v29_0.Progress = l_v29_0.Progress + 1;
                            v34();
                            if v29.Progress >= v29.MaxProgress then
                                v50();
                            end;
                        end;
                        return;
                    end;
                end));
                table.insert(v26, l_RunService_0.RenderStepped:Connect(function(v54) --[[ Line: 246 ]]
                    -- upvalues: v9 (ref), v31 (ref), v29 (ref), l_UserInputService_0 (ref), v30 (ref), v34 (copy), v20 (copy), v27 (ref), v50 (copy)
                    if not v9.Local.Character or v9.Local.Humanoid and v9.Local.Humanoid.Health <= 0 or v9.Local.Character and v9.Local.Character.Parent == nil or v9.Local.Character and v9.Local.Character:HasTag("Knocked") then
                        v31 = 1;
                        return;
                    else
                        if v29.Mode == "LeftRight" then
                            local l_X_0 = l_UserInputService_0:GetMouseLocation().X;
                            local v56 = v30 - l_X_0;
                            v30 = l_X_0;
                            local v57 = math.clamp(math.abs(v56 / 700) * 30, 0, 1);
                            if v57 > 0.5 then
                                local l_v29_1 = v29;
                                l_v29_1.Progress = l_v29_1.Progress + math.abs(v56 / 300);
                                v34();
                            elseif l_UserInputService_0:IsGamepadButtonDown(Enum.UserInputType.Gamepad1, Enum.KeyCode.ButtonX) then
                                local l_v29_2 = v29;
                                l_v29_2.Progress = l_v29_2.Progress + v54 * 8;
                                v57 = 1;
                                v34();
                            end;
                            if v20.Parent.CuttingBoard:FindFirstChild("Dough") then
                                for _, v61 in v20.Parent.CuttingBoard.Dough:GetChildren() do
                                    if tonumber(v61.Name) then
                                        v61.Transparency = lerp(v61.Transparency, v29.Progress / v29.MaxProgress >= tonumber(v61.Name) and 0 or 1, (math.clamp(v54 * 7, 0, 1)));
                                    end;
                                end;
                            end;
                            if v29.SubMode == "Package" then
                                v29.Progress = v27.TimePosition / v27.Length * v29.MaxProgress;
                                v57 = math.abs(v56 / 150);
                                if l_UserInputService_0:IsGamepadButtonDown(Enum.UserInputType.Gamepad1, Enum.KeyCode.ButtonX) then
                                    v57 = 0.6;
                                end;
                            end;
                            v27:AdjustSpeed(v57);
                            if v29.Progress >= v29.MaxProgress then
                                v50();
                                return;
                            end;
                        elseif v29.Mode == "Cook" then
                            local l_v29_3 = v29;
                            l_v29_3.Progress = l_v29_3.Progress + v54 * 4;
                            v34();
                            if v29.Progress >= v29.MaxProgress then
                                v50();
                            end;
                        end;
                        return;
                    end;
                end));
                repeat
                    task.wait();
                until v31;
                task.spawn(function() --[[ Line: 293 ]]
                    -- upvalues: v12 (ref)
                    v12:InvokeServer("End");
                end);
                v37(true);
                for _, v64 in v26 do
                    v64:Disconnect();
                end;
                l_LocalPlayer_0.CameraMinZoomDistance = game.StarterPlayer.CameraMinZoomDistance;
                v14 = false;
                v7.DisableMovement = false;
                v6.HideInventory("CookerJob", nil);
                if v9.Local.HRP then
                    v9.Local.HRP.Anchored = false;
                end;
                l_CookerJob_0.Visible = false;
                if v31 == true then
                    l_TweenService_0:Create(l_CurrentCamera_0, TweenInfo.new(0.45, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
                        CFrame = l_CFrame_0
                    }):Play();
                    task.wait(0.45);
                    l_CurrentCamera_0.CameraType = Enum.CameraType.Custom;
                else
                    l_CurrentCamera_0.CameraType = Enum.CameraType.Custom;
                end;
                return;
            end;
        end;
    end;
end;
return v0;
```

Shop items: (Focus on flour)

```

return {
    RestockTime = 15, 
    Items = {
        ["Anonymous Mask"] = {
            Cost = 150, 
            Stock = "Inf", 
            Image = "rbxassetid://130477386335824", 
            Order = 1
        }, 
        ["Light Armor"] = {
            Cost = 3000, 
            Stock = "Inf", 
            Image = "rbxassetid://108802284323142", 
            Order = 2
        }, 
        ["Duffel Bag"] = {
            Cost = 700, 
            Stock = "Inf", 
            Image = "http://www.roblox.com/asset/?id=12122896888", 
            Order = 3
        }, 
        Skimask = {
            Cost = 150, 
            Stock = "Inf", 
            Image = "rbxassetid://94676066081396", 
            Order = 4
        }, 
        ["Small Ink"] = {
            Cost = 50, 
            Stock = 20, 
            Image = "rbxassetid://128324016260833", 
            Order = 5
        }, 
        ["Medium Ink"] = {
            Cost = 150, 
            Stock = 6, 
            Image = "rbxassetid://73481224335016", 
            Order = 6, 
            ItemUnlock = "Printer"
        }, 
        ["Large Ink"] = {
            Cost = 450, 
            Stock = 4, 
            Image = "rbxassetid://95954984440915", 
            Order = 7, 
            ItemUnlock = "Printer"
        }, 
        ["Special Ink"] = {
            Cost = 500, 
            Stock = 2, 
            Image = "rbxassetid://88413320894470", 
            Order = 8, 
            ItemUnlock = "Printer"
        }, 
        ["Cookie Packet"] = {
            Cost = 50, 
            Stock = 20, 
            Image = "rbxassetid://131534348288613", 
            Order = 9
        }, 
        ["Standard Flour"] = {
            Cost = 30, 
            Stock = 15, 
            Image = "rbxassetid://82536994220356", 
            Order = 10
        }, 
        ["High-Quality Flour"] = {
            Cost = 130, 
            Stock = 6, 
            Image = "rbxassetid://105389730386527", 
            Order = 11, 
            ItemUnlock = "Baker"
        }, 
        ["Premium Flour"] = {
            Cost = 450, 
            Stock = 4, 
            Image = "rbxassetid://127248368918426", 
            Order = 12, 
            ItemUnlock = "Baker"
        }, 
        ["Luxurious Flour"] = {
            Cost = 650, 
            Stock = 3, 
            Image = "rbxassetid://126989108160209", 
            Order = 13, 
            ItemUnlock = "Baker"
        }
    }
};
```